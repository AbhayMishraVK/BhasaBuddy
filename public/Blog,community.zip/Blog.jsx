import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../assets/style/blog_style.css';

function BlogPage() {
    const [blogPosts, setBlogPosts] = useState([]);
    const email = "user@example.com"; // Replace with actual user's email

    useEffect(() => {
        fetchBlogPosts();
    }, []);

    const fetchBlogPosts = async () => {
        try {
            const url = `backend-url/posts?email=${email}`;
            const response = await axios.get(url);
            setBlogPosts(response.data);
        } catch (error) {
            console.error('Error fetching blog posts:', error);
        }
    };

    const sendTitleToBackend = (title) => {
        const data = { title: title };
        axios.post('backend-url/posts', data)
            .then(response => {
                console.log('Title sent to backend:', response.data);
            })
            .catch(error => {
                console.error('Error sending title to backend:', error);
            });
    };

    const handlePostClick = (title) => {
        sendTitleToBackend(title);
    };

    return (
        <div className="outer-container">
            <div className="container">
                <nav className="nav">
                    <h1>Bhasha Buddy Blogs</h1>
                    <span>Become fluent in any language</span>
                </nav>
                <div id="blog-posts">
                    {blogPosts.length > 0 && blogPosts.map(post => (
                        <div className="post" key={post.id} onClick={() => handlePostClick(post.title)}>
                            <div className="lp">
                                <img src={post.image} alt={post.title} />                
                            </div>
                            <div className="rp">
                                <h2>{post.title}</h2>
                                <p>{post.body}</p>
                            </div> 
                        </div> 
                    ))}
                    {blogPosts.length === 0 && <p>No blog posts found.</p>}
                </div>
            </div>
        </div>
    );
}

export default BlogPage;
